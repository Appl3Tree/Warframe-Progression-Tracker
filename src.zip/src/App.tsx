import App from "./app/App";

export default App;

