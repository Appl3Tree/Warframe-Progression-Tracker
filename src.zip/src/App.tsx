import DailyChecklist from "./components/DailyChecklist";
import ExportImport from "./components/ExportImport";
import InventoryPanel from "./components/InventoryPanel";
import ReservesPanel from "./components/ReservesPanel";
import SyndicatesGrid from "./components/SyndicatesGrid";

export default function App() {
    return (
        <div className="min-h-screen bg-slate-950 text-slate-100">
            <div className="mx-auto max-w-7xl px-4 py-8">
                <div className="flex flex-col gap-2">
                    <div className="text-2xl font-bold">Warframe Syndicate Roadmap Tracker</div>
                    <div className="text-sm text-slate-400">
                        Local-only tracker for daily checklists, rank-up requirements, and dependency-safe spending.
                    </div>
                </div>

                <div className="mt-6 grid grid-cols-1 xl:grid-cols-2 gap-4">
                    <DailyChecklist />
                    <ReservesPanel />
                </div>

                <div className="mt-4">
                    <InventoryPanel />
                </div>

                <div className="mt-4">
                    <ExportImport />
                </div>

                <div className="mt-6">
                    <div className="text-xl font-semibold mb-3">Syndicates</div>
                    <SyndicatesGrid />
                </div>
            </div>
        </div>
    );
}
