import { useMemo, useState } from "react";
import NumberField from "./NumberField";
import { useTrackerStore } from "../store/store";

export default function InventoryPanel() {
    const inventory = useTrackerStore((s) => s.inventory);
    const setCredits = useTrackerStore((s) => s.setCredits);
    const setVoidTraces = useTrackerStore((s) => s.setVoidTraces);
    const setAya = useTrackerStore((s) => s.setAya);
    const setItem = useTrackerStore((s) => s.setItemCount);

    const [filter, setFilter] = useState("");

    const itemKeys = useMemo(() => {
        const keys = Object.keys(inventory.items);
        keys.sort((a, b) => a.localeCompare(b));
        if (!filter.trim()) {
            return keys;
        }
        const f = filter.trim().toLowerCase();
        return keys.filter((k) => k.toLowerCase().includes(f));
    }, [inventory.items, filter]);

    return (
        <div className="rounded-2xl border border-slate-800 bg-slate-950/40 p-4">
            <div className="text-lg font-semibold">Inventory (what you have)</div>

            <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-3">
                <NumberField label="Credits" value={inventory.credits} onChange={setCredits} min={0} />
                <NumberField label="Void Traces" value={inventory.voidTraces} onChange={setVoidTraces} min={0} />
                <NumberField label="Aya" value={inventory.aya} onChange={setAya} min={0} />
            </div>

            <div className="mt-4">
                <input
                    className="w-full rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-slate-100"
                    placeholder="Filter items (e.g., token, matrix, toroid)"
                    value={filter}
                    onChange={(e) => setFilter(e.target.value)}
                />
            </div>

            <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3">
                {itemKeys.map((k) => (
                    <label key={k} className="flex items-center justify-between gap-3 rounded-xl border border-slate-800 bg-slate-900/30 px-3 py-2">
                        <div className="text-sm text-slate-200">{k}</div>
                        <input
                            className="w-32 rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-slate-100 text-right"
                            type="number"
                            min={0}
                            value={inventory.items[k] ?? 0}
                            onChange={(e) => setItem(k, Number(e.target.value))}
                        />
                    </label>
                ))}
            </div>
        </div>
    );
}
