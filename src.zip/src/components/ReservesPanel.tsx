import { useTrackerStore } from "../store/store";

export default function ReservesPanel() {
    const reserves = useTrackerStore((s) => s.reserves);
    const setEnabled = useTrackerStore((s) => s.setReserveEnabled);

    return (
        <div className="rounded-2xl border border-slate-800 bg-slate-950/40 p-4">
            <div className="text-lg font-semibold">Global Reserve Lock</div>
            <div className="text-sm text-slate-400 mt-1">
                These rules prevent you from “spending” items that are required later (e.g., Father Tokens needed for Necraloid rank-up).
            </div>

            <div className="mt-4 flex flex-col gap-3">
                {reserves.map((r) => (
                    <div key={r.id} className="rounded-xl border border-slate-800 bg-slate-900/30 p-3">
                        <div className="flex items-center justify-between gap-3">
                            <div className="font-semibold">{r.label}</div>
                            <label className="text-sm text-slate-300 flex items-center gap-2">
                                <input
                                    type="checkbox"
                                    checked={r.isEnabled}
                                    onChange={(e) => setEnabled(r.id, e.target.checked)}
                                />
                                Enabled
                            </label>
                        </div>
                        <div className="mt-2 text-sm text-slate-300">
                            {r.items.map((it) => (
                                <div key={`${r.id}_${it.key}`}>
                                    Keep ≥ <span className="font-semibold">{it.minKeep}</span> {it.key}
                                </div>
                            ))}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}
