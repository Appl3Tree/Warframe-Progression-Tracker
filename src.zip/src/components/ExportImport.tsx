import { useState } from "react";
import { useTrackerStore } from "../store/store";

export default function ExportImport() {
    const exportJson = useTrackerStore((s) => s.exportJson);
    const importJson = useTrackerStore((s) => s.importJson);

    const [text, setText] = useState("");

    return (
        <div className="rounded-2xl border border-slate-800 bg-slate-950/40 p-4">
            <div className="text-lg font-semibold">Export / Import</div>
            <div className="text-sm text-slate-400 mt-1">
                Use this to copy state into a new chat or move to another machine.
            </div>

            <div className="mt-3 flex gap-2">
                <button
                    className="rounded-lg bg-slate-100 px-4 py-2 text-slate-900 font-semibold"
                    onClick={() => setText(exportJson())}
                >
                    Export JSON
                </button>
                <button
                    className="rounded-lg border border-slate-700 px-4 py-2 text-slate-100"
                    onClick={() => {
                        const res = importJson(text);
                        if (!res.ok) {
                            alert(res.error ?? "Import failed.");
                        } else {
                            alert("Import OK.");
                        }
                    }}
                >
                    Import JSON
                </button>
                <button
                    className="rounded-lg border border-slate-700 px-4 py-2 text-slate-100"
                    onClick={() => setText("")}
                >
                    Clear
                </button>
            </div>

            <textarea
                className="mt-3 w-full min-h-[220px] rounded-xl bg-slate-900 border border-slate-700 px-3 py-2 text-slate-100 font-mono text-xs"
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Export JSON will appear here. You can also paste JSON here to import."
            />
        </div>
    );
}
