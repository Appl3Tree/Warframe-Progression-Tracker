import { useMemo, useState } from "react";
import { toYMD } from "../domain/ymd";
import { useTrackerStore } from "../store/store";

export default function DailyChecklist() {
    const today = useMemo(() => toYMD(new Date()), []);

    // Subscribe to the raw array only (stable snapshot behavior)
    const dailyTasks = useTrackerStore((s) => s.dailyTasks);

    // Derive filtered tasks in-component
    const tasks = useMemo(() => {
        return dailyTasks.filter((t) => t.dateYmd === today);
    }, [dailyTasks, today]);

    const upsert = useTrackerStore((s) => s.upsertDailyTask);
    const toggle = useTrackerStore((s) => s.toggleDailyTask);
    const del = useTrackerStore((s) => s.deleteDailyTask);

    const [label, setLabel] = useState("");
    const [syndicate, setSyndicate] = useState("");
    const [details, setDetails] = useState("");

    const doneCount = useMemo(() => tasks.filter((t) => t.isDone).length, [tasks]);

    return (
        <div className="rounded-2xl border border-slate-800 bg-slate-950/40 p-4">
            <div className="flex items-center justify-between gap-3">
                <div>
                    <div className="text-lg font-semibold">Daily Checklist</div>
                    <div className="text-sm text-slate-400">
                        {today} • {doneCount}/{tasks.length} done
                    </div>
                </div>
            </div>

            <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-3">
                <input
                    className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-slate-100"
                    placeholder="Task label (e.g., Farm 8 more Orokin Orientation Matrices)"
                    value={label}
                    onChange={(e) => setLabel(e.target.value)}
                />
                <input
                    className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-slate-100"
                    placeholder="Syndicate (optional)"
                    value={syndicate}
                    onChange={(e) => setSyndicate(e.target.value)}
                />
                <div className="flex gap-2">
                    <input
                        className="flex-1 rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-slate-100"
                        placeholder="Details (optional)"
                        value={details}
                        onChange={(e) => setDetails(e.target.value)}
                    />
                    <button
                        className="rounded-lg bg-slate-100 px-4 py-2 text-slate-900 font-semibold disabled:opacity-50"
                        disabled={label.trim().length === 0}
                        onClick={() => {
                            upsert(today, label.trim(), syndicate.trim() || undefined, details.trim() || undefined);
                            setLabel("");
                            setSyndicate("");
                            setDetails("");
                        }}
                    >
                        Add
                    </button>
                </div>
            </div>

            <div className="mt-4 flex flex-col gap-2">
                {tasks.length === 0 && (
                    <div className="text-sm text-slate-400">
                        No tasks for today yet. Add tasks that represent what you intend to do before reset.
                    </div>
                )}

                {tasks.map((t) => (
                    <div
                        key={t.id}
                        className="flex items-center justify-between gap-3 rounded-xl border border-slate-800 bg-slate-900/30 px-3 py-2"
                    >
                        <label className="flex items-start gap-3">
                            <input
                                type="checkbox"
                                checked={t.isDone}
                                onChange={() => toggle(t.id)}
                                className="mt-1"
                            />
                            <div>
                                <div className={t.isDone ? "line-through text-slate-400" : "text-slate-100"}>
                                    {t.label}
                                </div>
                                {(t.syndicate || t.details) && (
                                    <div className="text-xs text-slate-400">
                                        {t.syndicate ? `[${t.syndicate}] ` : ""}
                                        {t.details ?? ""}
                                    </div>
                                )}
                            </div>
                        </label>

                        <button
                            className="rounded-lg border border-slate-700 px-3 py-1 text-sm text-slate-200 hover:bg-slate-800"
                            onClick={() => del(t.id)}
                        >
                            Delete
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );
}
