import { useTrackerStore } from "../store/store";
import SyndicateCard from "./SyndicateCard";

export default function SyndicatesGrid() {
    const syndicates = useTrackerStore((s) => s.syndicates);

    return (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
            {syndicates.map((syn) => (
                <SyndicateCard key={syn.id} syndicate={syn} />
            ))}
        </div>
    );
}
