import { create } from "zustand";
import { immer } from "zustand/middleware/immer";
import { z } from "zod";
import { toYMD } from "../domain/ymd";
import type { DailyTask, Inventory, ReserveRule, SyndicateState } from "../domain/types";
import { SEED_INVENTORY, SEED_RESERVES, SEED_SYNDICATES } from "../domain/seed";

const StorageSchema = z.object({
    inventory: z.any(),
    syndicates: z.any(),
    reserves: z.any(),
    dailyTasks: z.any()
});

const STORAGE_KEY = "wf_roadmap_tracker_v1";

function loadStorage(): {
    inventory: Inventory;
    syndicates: SyndicateState[];
    reserves: ReserveRule[];
    dailyTasks: DailyTask[];
} | null {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
        return null;
    }
    try {
        const parsed = JSON.parse(raw);
        const ok = StorageSchema.safeParse(parsed);
        if (!ok.success) {
            return null;
        }
        return parsed;
    } catch {
        return null;
    }
}

function saveStorage(state: TrackerState): void {
    const payload = {
        inventory: state.inventory,
        syndicates: state.syndicates,
        reserves: state.reserves,
        dailyTasks: state.dailyTasks
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
}

function uid(prefix: string): string {
    return `${prefix}_${Math.random().toString(16).slice(2)}_${Date.now()}`;
}

export interface TrackerState {
    inventory: Inventory;
    syndicates: SyndicateState[];
    reserves: ReserveRule[];
    dailyTasks: DailyTask[];

    setCredits: (credits: number) => void;
    setVoidTraces: (traces: number) => void;
    setAya: (aya: number) => void;

    setItemCount: (key: string, count: number) => void;

    upsertDailyTask: (dateYmd: string, label: string, syndicate?: string, details?: string) => void;
    toggleDailyTask: (taskId: string) => void;
    deleteDailyTask: (taskId: string) => void;

    setSyndicateNotes: (id: string, notes: string) => void;
    setReserveEnabled: (reserveId: string, enabled: boolean) => void;

    exportJson: () => string;
    importJson: (json: string) => { ok: boolean; error?: string };

    // Calculations
    getTodayTasks: () => DailyTask[];
    isBelowReserve: (key: string, spendAmount: number) => { blocked: boolean; reasons: string[] };
}

const boot = loadStorage();

export const useTrackerStore = create<TrackerState>()(
    immer((set, get) => ({
        inventory: boot?.inventory ?? SEED_INVENTORY,
        syndicates: boot?.syndicates ?? SEED_SYNDICATES,
        reserves: boot?.reserves ?? SEED_RESERVES,
        dailyTasks: boot?.dailyTasks ?? [],

        setCredits: (credits) => {
            set((s) => {
                s.inventory.credits = credits;
            });
            saveStorage(get());
        },
        setVoidTraces: (traces) => {
            set((s) => {
                s.inventory.voidTraces = traces;
                s.inventory.items["Void Traces"] = traces;
            });
            saveStorage(get());
        },
        setAya: (aya) => {
            set((s) => {
                s.inventory.aya = aya;
                s.inventory.items["aya"] = aya;
                s.inventory.items["Aya"] = aya;
            });
            saveStorage(get());
        },

        setItemCount: (key, count) => {
            set((s) => {
                s.inventory.items[key] = count;
                if (key === "Void Traces") {
                    s.inventory.voidTraces = count;
                }
                if (key === "aya" || key === "Aya") {
                    s.inventory.aya = count;
                }
                if (key === "credits") {
                    s.inventory.credits = count;
                }
            });
            saveStorage(get());
        },

        upsertDailyTask: (dateYmd, label, syndicate, details) => {
            set((s) => {
                const existing = s.dailyTasks.find(
                    (t) => t.dateYmd === dateYmd && t.label.trim().toLowerCase() === label.trim().toLowerCase()
                );
                if (existing) {
                    existing.syndicate = syndicate;
                    existing.details = details;
                    return;
                }
                s.dailyTasks.push({
                    id: uid("task"),
                    dateYmd,
                    label,
                    syndicate,
                    details,
                    isDone: false
                });
            });
            saveStorage(get());
        },
        toggleDailyTask: (taskId) => {
            set((s) => {
                const t = s.dailyTasks.find((x) => x.id === taskId);
                if (t) {
                    t.isDone = !t.isDone;
                }
            });
            saveStorage(get());
        },
        deleteDailyTask: (taskId) => {
            set((s) => {
                s.dailyTasks = s.dailyTasks.filter((t) => t.id !== taskId);
            });
            saveStorage(get());
        },

        setSyndicateNotes: (id, notes) => {
            set((s) => {
                const syn = s.syndicates.find((x) => x.id === id);
                if (syn) {
                    syn.notes = notes;
                }
            });
            saveStorage(get());
        },

        setReserveEnabled: (reserveId, enabled) => {
            set((s) => {
                const r = s.reserves.find((x) => x.id === reserveId);
                if (r) {
                    r.isEnabled = enabled;
                }
            });
            saveStorage(get());
        },

        exportJson: () => {
            const state = get();
            return JSON.stringify(
                {
                    inventory: state.inventory,
                    syndicates: state.syndicates,
                    reserves: state.reserves,
                    dailyTasks: state.dailyTasks
                },
                null,
                2
            );
        },

        importJson: (json) => {
            try {
                const parsed = JSON.parse(json);
                const ok = StorageSchema.safeParse(parsed);
                if (!ok.success) {
                    return { ok: false, error: "Import JSON shape invalid." };
                }
                set((s) => {
                    s.inventory = parsed.inventory;
                    s.syndicates = parsed.syndicates;
                    s.reserves = parsed.reserves;
                    s.dailyTasks = parsed.dailyTasks;
                });
                saveStorage(get());
                return { ok: true };
            } catch (e) {
                return { ok: false, error: e instanceof Error ? e.message : "Unknown import error." };
            }
        },

        getTodayTasks: () => {
            const today = toYMD(new Date());
            return get().dailyTasks.filter((t) => t.dateYmd === today);
        },

        isBelowReserve: (key, spendAmount) => {
            const { inventory, reserves } = get();
            const reasons: string[] = [];

            const current = inventory.items[key] ?? 0;
            const afterSpend = current - spendAmount;

            for (const rule of reserves) {
                if (!rule.isEnabled) {
                    continue;
                }
                for (const item of rule.items) {
                    if (item.key === key) {
                        if (afterSpend < item.minKeep) {
                            reasons.push(`${rule.label}: keep at least ${item.minKeep} ${key} (would drop to ${afterSpend}).`);
                        }
                    }
                    if (item.key === "Void Traces" && key === "Void Traces") {
                        if (afterSpend < item.minKeep) {
                            reasons.push(`${rule.label}: keep at least ${item.minKeep} Void Traces (would drop to ${afterSpend}).`);
                        }
                    }
                }
            }

            return { blocked: reasons.length > 0, reasons };
        }
    }))
);
